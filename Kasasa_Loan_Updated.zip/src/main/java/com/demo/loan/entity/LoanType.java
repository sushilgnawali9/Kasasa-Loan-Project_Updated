package com.demo.loan.entity;

public enum LoanType {
    STUDENT,
    AUTO,
    PERSONAL,
    MORTGAGE
}
